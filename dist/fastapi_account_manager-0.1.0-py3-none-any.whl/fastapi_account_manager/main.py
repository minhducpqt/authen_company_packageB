from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.responses import RedirectResponse

from fastapi_authen import auth_router, current_user, User
from .middlewares.auth_middleware import AuthMiddleware
from .routers.accounts import router as accounts_router
from .routers.admin import router as admin_router
from .routers.super import router as super_router

import os

LOGIN_REDIRECT_URL = os.getenv("LOGIN_REDIRECT_URL", "/accounts/dashboard")

def create_app() -> FastAPI:
    app = FastAPI(title="FastAPI Account Manager")

    # static & templates (module-internal)
    app.mount("/accounts/static", StaticFiles(directory=f"{__package__.replace('.', '/')}/static"), name="am_static")
    templates = Jinja2Templates(directory=f"{__package__.replace('.', '/')}/templates")

    # middleware: auto refresh & login redirect
    app.add_middleware(AuthMiddleware)

    # auth endpoints from Module A (mounted at /auth)
    app.include_router(auth_router, prefix="")

    # module B routers
    app.include_router(accounts_router, prefix="/accounts")
    app.include_router(admin_router, prefix="/accounts")
    app.include_router(super_router, prefix="/accounts")

    # entry: /accounts -> redirect login/dashboard depending on auth
    @app.get("/accounts")
    def accounts_index(request: Request, user: User = current_user):
        return RedirectResponse(LOGIN_REDIRECT_URL, status_code=303)

    # a minimal dashboard (server-rendered here for convenience)
    @app.get("/accounts/dashboard")
    def dashboard(request: Request, user: User = current_user):
        return templates.TemplateResponse("dashboard.html", {"request": request, "me": user})

    return app
