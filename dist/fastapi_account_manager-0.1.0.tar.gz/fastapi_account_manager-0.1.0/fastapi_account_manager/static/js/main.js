// keep minimal; place for enhancements later
console.log("fastapi-account-manager loaded");
